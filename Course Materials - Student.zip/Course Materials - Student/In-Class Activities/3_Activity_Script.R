divide_and_round <- function(nums){
  
  my_mean <-1
  divided <- nums/my_mean
  rounded <- 0
  
  rounded
  
}


every_other <- function(vec, start = 1){
  
  new_vec <- c()
  
  for(val in vec){
    
    if(){
      
      new_vec <- c(new_vec, val)
      
    }
    
  }
  
  new_vec
  
}